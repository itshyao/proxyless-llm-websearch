<!-- popup.js -->
document.addEventListener("DOMContentLoaded", () => {
  const modeSelect = document.getElementById("mode");
  const sections = {
    current: document.getElementById("current-section"),
    tabs: document.getElementById("tabs-section"),
    custom: document.getElementById("custom-section")
  };
  const resultDiv = document.getElementById("result");
  const tabList = document.getElementById("tab-list");
  const customUrls = document.getElementById("custom-urls");
  const serverInput = document.getElementById("server");
  const saveServerBtn = document.getElementById("save-server");

  // 恢复服务器地址、自定义URL和解析结果
  chrome.storage.local.get(["server", "customUrls", "lastResult"], data => {
    serverInput.value = data.server || "http://localhost:8000";
    if (data.customUrls) customUrls.value = data.customUrls;
    if (data.lastResult) resultDiv.textContent = data.lastResult;
  });

  customUrls.addEventListener("input", () => {
    chrome.storage.local.set({ customUrls: customUrls.value });
  });

  saveServerBtn.addEventListener("click", () => {
    const newServer = serverInput.value.trim();
    chrome.storage.local.set({ server: newServer }, () => {
      alert("接口地址已保存");
    });
  });

  modeSelect.addEventListener("change", () => {
    Object.values(sections).forEach(sec => sec.style.display = "none");
    sections[modeSelect.value].style.display = "block";
    if (modeSelect.value === "tabs") loadTabs();
  });

  function loadTabs() {
    tabList.innerHTML = "加载中...";
    chrome.tabs.query({ currentWindow: true }, tabs => {
      tabList.innerHTML = tabs.map(tab => `
        <div>
          <label>
            <input type="checkbox" value="${tab.url}" class="tab-checkbox" />
            ${tab.title || tab.url}
          </label>
        </div>
      `).join("");

      tabList.querySelectorAll('.tab-checkbox').forEach(cb => {
        cb.addEventListener("change", () => {
          const selected = [...tabList.querySelectorAll("input:checked")];
          if (selected.length > 5) {
            cb.checked = false;
            alert("最多只能选择5个标签页进行解析。");
          }
        });
      });
    });
  }

  async function sendRequest(urls) {
    chrome.storage.local.get("server", async data => {
      const server = data.server || "http://localhost:8000/search";
      let output = "";
      for (const url of urls) {
        output += `\n🔗 ${url}\n解析中...\n`;
        resultDiv.textContent = output;
        try {
          const res = await fetch(`${server}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url })
          });
          const json = await res.json();
          output += `✅ ${json.data || JSON.stringify(json)}\n`;
        } catch (err) {
          output += `❌ 解析失败: ${err.message}\n`;
        }
        resultDiv.textContent = output;
        chrome.storage.local.set({ lastResult: output });
      }
    });
  }

  document.getElementById("parse-current").addEventListener("click", () => {
    resultDiv.textContent = "正在解析当前页面...";
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (tabs.length > 0) sendRequest([tabs[0].url]);
    });
  });

  document.getElementById("parse-tabs").addEventListener("click", () => {
    const urls = [...tabList.querySelectorAll("input:checked")].map(i => i.value);
    if (urls.length > 0) sendRequest(urls);
    else resultDiv.textContent = "请选择至少一个页面";
  });

  document.getElementById("parse-custom").addEventListener("click", () => {
    const urls = customUrls.value.split(/\n|\s/).filter(Boolean);
    if (urls.length > 5) {
      resultDiv.textContent = "最多只能输入5个 URL";
      return;
    }
    if (urls.length > 0) sendRequest(urls);
    else resultDiv.textContent = "请输入至少一个 URL";
  });

  document.getElementById("clear-result").addEventListener("click", () => {
    resultDiv.textContent = "";
    chrome.storage.local.remove("lastResult");
  });
});
